
clear;
clc;
close all;

s = tf('s');

% System transfer functions
Gs = -10/(s + 10);
P = (-4.5*s + 0.75)/(s^2 + 1.1*s + 4.2);

% Selected yaw-damper parameters
K1 = 0.25;
tau = 2;
Hw = s/(s + 1/tau);

% Damper OFF and ON
T_off = Gs*P;
T_on = feedback(Gs*P, K1*Hw);

% Simulation settings: identical unit-step input
t = (0:0.001:20)';
u = ones(size(t));

y_off = lsim(T_off, u, t);
y_on  = lsim(T_on, u, t);

% Plot comparison
figure;
plot(t, y_off, 'LineWidth', 1.5);
hold on;
plot(t, y_on, 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Yaw rate');
title('Yaw-Rate Response: Damper OFF vs ON');
legend('Damper OFF', 'Damper ON', 'Location', 'best');

% Calculate performance metrics
responses = {y_off, y_on};
names = {'Damper OFF', 'Damper ON'};

for i = 1:2
    y = responses{i};
    y_final = dcgain([T_off, T_on]);
    final_value = y_final(i);

    [y_max, i_max] = max(y);
    [y_min, i_min] = min(y);

    % Settling time: 2% band around theoretical final value
    tol = 0.02 * abs(final_value);
    idx = find(abs(y - final_value) > tol, 1, 'last');

    if isempty(idx)
        settling_time = 0;
    elseif idx < numel(t)
        settling_time = t(idx + 1);
    else
        settling_time = NaN;
    end

    fprintf('\n%s\n', names{i});
    fprintf('Theoretical final yaw rate: %.6f\n', final_value);
    fprintf('Simulated final yaw rate: %.6f\n', y(end));
    fprintf('Maximum yaw rate: %.6f at %.3f s\n', ...
        y_max, t(i_max));
    fprintf('Minimum yaw rate: %.6f at %.3f s\n', ...
        y_min, t(i_min));

    if isnan(settling_time)
        fprintf('Not settled within 20 s.\n');
    else
        fprintf('2%% settling time: %.3f s\n', settling_time);
    end
end

% Pole and damping comparison
disp(' ');
disp('Damper OFF poles and damping:');
damp(T_off);

disp('Damper ON poles and damping:');
damp(T_on);
