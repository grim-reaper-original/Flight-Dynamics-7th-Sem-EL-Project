% Simulink settling-time calculation
out = sim('EL');

yaw_rate = out.yaw_rate;
t_sim = yaw_rate.Time(:);
y_sim = squeeze(yaw_rate.Data);
y_sim = y_sim(:);

% Final value and 2% settling band
y_final = y_sim(end);
tol = 0.02 * abs(y_final);

upper_bound = y_final + tol;
lower_bound = y_final - tol;

% Find the last sample outside the settling band
idx = find(y_sim < lower_bound | y_sim > upper_bound, 1, 'last');

if isempty(idx)
    settling_time = t_sim(1);
elseif idx < numel(t_sim)
    settling_time = t_sim(idx + 1);
else
    settling_time = NaN;
end

fprintf('Final yaw rate: %.6f\n', y_final);
fprintf('2%% settling band: [%.6f, %.6f]\n', ...
    lower_bound, upper_bound);

if isnan(settling_time)
    fprintf('System did not settle within %.2f seconds.\n', t_sim(end));
else
    fprintf('Simulink 2%% settling time: %.4f s\n', settling_time);
end