clear;
clc;
close all;

s = tf('s');

% System parameters
Gs = -10/(s + 10);
P  = (-4.5*s + 0.75)/(s^2 + 1.1*s + 4.2);
K1 = 0.25;
tau = 2;
Hw = s/(s + 1/tau);

% Transfer function from COMMAND to RUDDER DEFLECTION
% T_delta = Gs / (1 + K1*Hw*P*Gs)
T_delta = feedback(Gs, K1*Hw*P);

% Simulation time
t = (0:0.001:20)';

% 1. Step Command (1 degree)
u_step = ones(size(t));
delta_step = lsim(T_delta, u_step, t);

% 2. Pulse Command (2 degrees for 1 second)
u_pulse = 2*(t >= 0) - 2*(t >= 1);
delta_pulse = lsim(T_delta, u_pulse, t);

% Plot limits
figure;
subplot(2,1,1);
plot(t, delta_step, 'LineWidth', 1.5); hold on;
yline(20, 'r--', 'Limit (+20)'); yline(-20, 'r--', 'Limit (-20)');
grid on; title('Rudder Deflection: 1° Step Command');
xlabel('Time (s)'); ylabel('\delta_r (deg)');
ylim([-25 25]);

subplot(2,1,2);
plot(t, delta_pulse, 'LineWidth', 1.5); hold on;
yline(20, 'r--', 'Limit (+20)'); yline(-20, 'r--', 'Limit (-20)');
grid on; title('Rudder Deflection: 2° Pulse Command');
xlabel('Time (s)'); ylabel('\delta_r (deg)');
ylim([-25 25]);

% Console Output
fprintf('Max rudder deflection (Step): %.3f degrees\n', max(abs(delta_step)));
fprintf('Max rudder deflection (Pulse): %.3f degrees\n', max(abs(delta_pulse)));