% Define the Laplace variable
s = tf('s');

% Define the open-loop aircraft plant P(s)
P = (-4.5*s + 0.75) / (s^2 + 1.1*s + 4.2);

% 1. Calculate open-loop poles and zero
disp('Open-Loop Poles:');
open_loop_poles = pole(P)

disp('Open-Loop Zero:');
open_loop_zero = zero(P)

% 2. Calculate modal parameters (damping ratio, natural frequency, time constant)
disp('Modal Parameters:');
damp(P)

% 3. Calculate the steady-state value (DC gain) for a unit step
disp('Steady-State Value (DC Gain):');
steady_state_value = dcgain(P)

% 4. Plot the open-loop step response
figure;
step(P, 20);
grid on;
title('Open-Loop Step Response of Aircraft Plant P(s)');