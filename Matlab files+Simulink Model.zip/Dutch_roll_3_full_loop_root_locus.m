clear;
clc;
close all;

s = tf('s');

% Servo transfer function
Gs = -10/(s + 10);

% Aircraft yaw-rate transfer function
P = (-4.5*s + 0.75)/(s^2 + 1.1*s + 4.2);

% Washout filter
Hw = s/(s + 0.5);

% Complete forward-path dynamics, excluding feedback gain
L0 = Gs*P*Hw;

% Root locus for the complete loop
figure;
rlocus(L0);
grid on;
title('Full Yaw-Damper Root Locus');

% Evaluate selected gains
K_values = [0.05 0.1 0.15 0.2 0.25 0.3 0.4 0.5];

for K = K_values
    T = feedback(K*L0, 1);
    p = pole(T);

    fprintf('\nK = %.3f\n', K);
    disp('Closed-loop poles:');
    disp(p);

    disp('Damping ratios and natural frequencies:');
    damp(T);
end