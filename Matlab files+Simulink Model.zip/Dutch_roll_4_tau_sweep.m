clear;
clc;
close all;

s = tf('s');

% Servo transfer function
Gs = -10/(s + 10);

% Aircraft yaw-rate transfer function
P = (-4.5*s + 0.75)/(s^2 + 1.1*s + 4.2);

% Washout filter
Hw = s/(s + 0.5);

% Complete forward-path dynamics, excluding feedback gain
L0 = Gs*P*Hw;

s = tf('s');
K1 = 0.25;
tau_values = 1:1:4;

results = zeros(length(tau_values), 4);

for i = 1:length(tau_values)
    tau = tau_values(i);

    % Washout filter
    Hw = s / (s + 1/tau);

    % Closed-loop command-to-yaw-rate transfer function
    T_yaw = feedback(Gs*P, K1*Hw);

    % Closed-loop poles
    p = pole(T_yaw);

    % Identify the complex-conjugate Dutch-roll pair
    complex_poles = p(imag(p) > 1e-6);

    if ~isempty(complex_poles)
        [~, idx] = max(imag(complex_poles));
        p_dr = complex_poles(idx);

        wn = abs(p_dr);
        zeta = -real(p_dr)/wn;
    else
        wn = NaN;
        zeta = NaN;
    end

    % Steady-state yaw rate for a unit-step command
    y_final = dcgain(T_yaw);

    results(i,:) = [tau, zeta, wn, y_final];
end

ResultTable = array2table(results, ...
    'VariableNames', ...
    {'Tau_s','DutchRollDamping','NaturalFrequency_rad_s', ...
     'SteadyStateYawRate'});

disp(ResultTable);