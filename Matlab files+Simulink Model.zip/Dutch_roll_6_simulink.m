out = sim('EL');

yaw_rate = out.yaw_rate;

t_sim = yaw_rate.Time(:);
y_sim = squeeze(yaw_rate.Data);
y_sim = y_sim(:);

figure;
plot(t_sim, y_sim, 'LineWidth', 1.5);
grid on;
title('Simulink Closed-Loop Yaw-Rate Step Response');
xlabel('Time (s)');
ylabel('Yaw rate');

y_final = y_sim(end);
[y_max, i_max] = max(y_sim);
[y_min, i_min] = min(y_sim);

fprintf('Final yaw rate: %.6f\n', y_final);
fprintf('Maximum yaw rate: %.6f at %.4f s\n', ...
    y_max, t_sim(i_max));
fprintf('Minimum yaw rate: %.6f at %.4f s\n', ...
    y_min, t_sim(i_min));