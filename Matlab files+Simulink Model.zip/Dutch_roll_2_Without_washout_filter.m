clear;
clc;
close all;

s = tf('s');

% Aircraft yaw-rate transfer function
P = (-4.5*s + 0.75)/(s^2 + 1.1*s + 4.2);

% Rudder servo transfer function
Gs = -10/(s + 10);

% Loop transfer function WITHOUT washout filter
L_no_washout = Gs * P;

% Root locus plot
figure;
rlocus(L_no_washout);
grid on;
title('Root Locus Without Washout Filter');

% Evaluate specific gains to match the report table
K_values = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50];

fprintf('\n--- Poles and Damping Without Washout Filter ---\n');
for K = K_values
    % Unity negative-feedback loop
    T = feedback(K * L_no_washout, 1);
    
    fprintf('\nGain (K) = %.2f\n', K);
    disp('Closed-loop poles:');
    disp(pole(T));
    
    disp('Damping ratios and natural frequencies:');
    damp(T);
end