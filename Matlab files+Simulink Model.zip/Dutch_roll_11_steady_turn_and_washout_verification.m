
clear;
clc;
close all;

s = tf('s');

% Washout filter, tau = 2 s
tau = 2;
Hw = s/(s + 1/tau);

% Constant yaw-rate reference: step from 0 to 1
t = (0:0.001:20)';
r_ref = ones(size(t));

% Filter response to constant yaw rate
y_filter = lsim(Hw, r_ref, t);

% Plot
figure;
plot(t, r_ref, '--', 'LineWidth', 1.3);
hold on;
plot(t, y_filter, 'LineWidth', 1.5);
grid on;

xlabel('Time (s)');
ylabel('Signal value');
title('Washout Filter Response to a Constant Yaw-Rate Input');
legend('Constant yaw-rate input', ...
       'Washout-filter output', ...
       'Location', 'best');

% Numerical results
fprintf('Washout filter: Hw(s) = s/(s + %.2f)\n', 1/tau);
fprintf('Theoretical DC gain: %.6f\n', dcgain(Hw));
fprintf('Initial filter output: %.6f\n', y_filter(1));
fprintf('Maximum filter output: %.6f\n', max(y_filter));
fprintf('Final filter output: %.8f\n', y_filter(end));

% Check the late-time output
fprintf('Output at 10 s: %.8f\n', ...
    y_filter(round(10/0.001) + 1));
