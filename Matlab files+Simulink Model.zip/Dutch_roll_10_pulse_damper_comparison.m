
clear;
clc;
close all;

s = tf('s');

% Existing system parameters
Gs = -10/(s + 10);
P  = (-4.5*s + 0.75)/(s^2 + 1.1*s + 4.2);

K1 = 0.25;
tau = 2;

Hw = s/(s + 1/tau);

% Damper OFF and ON transfer functions
T_off = Gs*P;
T_on  = feedback(Gs*P, K1*Hw);

% 2-degree pulse, duration 1 second
t = (0:0.001:20)';
u = 2*(t >= 0) - 2*(t >= 1);

% Simulate both responses
y_off = lsim(T_off, u, t);
y_on  = lsim(T_on,  u, t);

% Plot comparison
figure;
plot(t, y_off, 'LineWidth', 1.4);
hold on;
plot(t, y_on, 'LineWidth', 1.4);
grid on;

xlabel('Time (s)');
ylabel('Yaw rate');
title('Yaw-Rate Pulse Response: Damper OFF vs ON');
legend('Damper OFF', 'Damper ON', 'Location', 'best');

% Calculate response metrics
responses = {y_off, y_on};
names = {'Damper OFF', 'Damper ON'};

for i = 1:2
    y = responses{i};

    [ymax, imax] = max(y);
    [ymin, imin] = min(y);

    % Settling band: 2% of peak absolute response
    % Appropriate for this pulse, whose final value is zero.
    band = 0.02 * max(abs(y));

    idx = find(abs(y) > band, 1, 'last');

    if isempty(idx)
        ts = 0;
    elseif idx < numel(t)
        ts = t(idx + 1);
    else
        ts = NaN;
    end

    fprintf('\n%s\n', names{i});
    fprintf('Maximum yaw rate: %.6f at %.3f s\n', ...
        ymax, t(imax));
    fprintf('Minimum yaw rate: %.6f at %.3f s\n', ...
        ymin, t(imin));
    fprintf('Final yaw rate: %.6f\n', y(end));
    fprintf('2%% peak-relative settling time: %.3f s\n', ts);
end
