model = 'EL';
out = sim(model);

yaw_rate = out.yaw_rate;

t = yaw_rate.Time(:);
y = squeeze(yaw_rate.Data);
y = y(:);

% Final value and extrema
y_final = y(end);
[y_max, i_max] = max(y);
[y_min, i_min] = min(y);

fprintf('\nSimulink yaw-rate metrics — Damper OFF\n');
fprintf('Final yaw rate: %.6f\n', y_final);
fprintf('Maximum yaw rate: %.6f at %.4f s\n', ...
    y_max, t(i_max));
fprintf('Minimum yaw rate: %.6f at %.4f s\n', ...
    y_min, t(i_min));

% 2% settling time relative to final value
tol = 0.02 * abs(y_final);
idx = find(abs(y - y_final) > tol, 1, 'last');

if isempty(idx)
    settling_time = t(1);
elseif idx < numel(t)
    settling_time = t(idx + 1);
else
    settling_time = NaN;
end

if isnan(settling_time)
    fprintf('Not settled within %.2f s\n', t(end));
else
    fprintf('2%% settling time: %.4f s\n', settling_time);
end